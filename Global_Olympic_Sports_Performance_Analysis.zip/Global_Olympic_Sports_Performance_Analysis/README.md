# Global Olympic Sports Performance Analysis

## Project purpose
Explore Olympic medal patterns by country, year, and sport using Tableau. The package contains a ready-to-open demonstration dashboard and Tableau-ready CSV files.

## Important data note
The included CSV files are **small sample/demo data** for building and testing the project structure. They are **not a complete official medal dataset**. Replace them with the full dataset before submitting as a final evidence-based analysis.

## Files
- `data/olympic_medal_summary_sample.csv` — country/year medal totals (sample).
- `data/sport_medal_sample.csv` — country/sport medal counts (sample).
- `dashboard/index.html` — interactive demo dashboard (open in a browser).
- `report/Project_Report.pdf` — report with objectives, methodology, findings scope, limitations and conclusion.
- `presentation/Project_Presentation.pptx` — editable presentation.
- `TABLEAU_BUILD_GUIDE.md` — step-by-step Tableau dashboard construction.
- `DATA_SOURCE.md` — dataset attribution and replacement instructions.

## How to use
1. Open `dashboard/index.html` in Chrome to preview the dashboard.
2. Open Tableau Public/Desktop.
3. Connect to `data/olympic_medal_summary_sample.csv`.
4. Follow `TABLEAU_BUILD_GUIDE.md` to create worksheets and a dashboard.
5. Replace sample CSVs with a complete verified dataset and refresh Tableau before final submission.

## Data source
A publicly available Olympic medalist dataset is described in the repository below. Verify field meanings, completeness and licensing before using it in a submitted project:
https://github.com/sainsdataid/olympics-medalist-dataset
Credit the dataset compiler and its stated upstream source as appropriate.
