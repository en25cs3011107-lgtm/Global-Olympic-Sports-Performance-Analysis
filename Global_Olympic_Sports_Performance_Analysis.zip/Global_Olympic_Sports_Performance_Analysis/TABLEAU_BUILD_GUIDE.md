# Tableau Build Guide (beginner friendly)

## Connect data
1. Open Tableau Public.
2. Choose **Text File** and select `data/olympic_medal_summary_sample.csv`.
3. Check that `Year`, `Country`, `Season`, `Gold`, `Silver`, `Bronze`, and `Total_Medals` are recognised correctly.
4. If `Year` appears as text, change its data type to Number (Whole).

## Worksheet 1 — Medal leaderboard
- Drag `Country` to Rows.
- Drag `Total_Medals` to Columns.
- Sort descending.
- Drag `Year` to Filters.
- Title: **Medal Count by Country**.

## Worksheet 2 — Medal trend over time
- Drag `Year` to Columns.
- Drag `Total_Medals` to Rows.
- Drag `Country` to Color.
- Use Line marks.
- Title: **Country Medal Trends Across Olympic Editions**.
- Note: sample data only includes selected country/year combinations; use the full dataset for meaningful trends.

## Worksheet 3 — Medal composition
- Drag `Country` to Rows.
- Drag `Measure Names` to Columns.
- Drag `Measure Values` to Text.
- Filter Measure Names to Gold, Silver, Bronze.
- Title: **Gold, Silver and Bronze by Country**.

## Worksheet 4 — Sport performance
- Connect `sport_medal_sample.csv` as a second data source.
- Drag `Sport` to Rows and `Total_Medals` to Columns.
- Drag `Country` to Color.
- Title: **Medals by Sport and Country**.

## Dashboard
- Click New Dashboard.
- Add the leaderboard, trend, composition and sport charts.
- Add Year, Season and Country filters where appropriate.
- Add a short text box: “Educational dashboard. Validate against the full source dataset before drawing final conclusions.”
- Save as a Tableau Packaged Workbook (`.twbx`) if available.

## Suggested insights to investigate after replacing sample data
- Which countries lead total and gold medal counts?
- How does each country's medal count change between Olympic editions?
- Which sports contribute the most medals to each country?
- How does Summer performance compare with Winter performance?
- Which countries show the largest change from one edition to the next?
