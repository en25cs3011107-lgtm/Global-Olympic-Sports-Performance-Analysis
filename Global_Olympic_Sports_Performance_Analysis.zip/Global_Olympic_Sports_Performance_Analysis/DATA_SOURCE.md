# Data Source and Limitations

The project theme requires a complete, reliable Olympic dataset. This starter package includes **illustrative sample rows only** so the dashboard and report structure can be used immediately.

A public medalist dataset for 1896–2024 is available here:
https://github.com/sainsdataid/olympics-medalist-dataset

The repository describes columns including season, year, medal, country code, country, athlete(s), games, sport, event gender, and event name. It says its data was extracted from the OlympAnalyt portal and is intended for educational/research use.

For final analysis:
1. Download the complete CSV from the repository.
2. Check the column names and duplicate rows.
3. Filter the years and seasons required by your assignment.
4. Aggregate medal counts by country/year and by country/sport.
5. Cite the dataset in the report and dashboard.
6. Do not describe sample/demo results as official findings.
